package practica2;

public class Url {

}
